
import React, { Component } from 'react';

class WelcomeToClassCompo extends Component {
    render() {
        return (
            <div>
                <h2>Welcome To Class Component</h2>

                <p>Class is a collection of datamember and member function only</p>
                <p>in react we have render as default method for getting output from class compo</p>
            </div>
        );
    }
}

export default WelcomeToClassCompo;
